# AMuSeD_iridium_adapter

PCB design for a simple Iridium adapter