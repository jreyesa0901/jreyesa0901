/*
 * Code generated from Atmel Start.
 *
 * This file will be overwritten when reconfiguring your Atmel Start project.
 * Please copy examples or other code you want to keep to a separate file
 * to avoid losing it when reconfiguring.
 */
#ifndef DRIVER_INIT_INCLUDED
#define DRIVER_INIT_INCLUDED

#include "atmel_start_pins.h"

#ifdef __cplusplus
extern "C" {
#endif

#include <hal_atomic.h>
#include <hal_delay.h>
#include <hal_gpio.h>
#include <hal_init.h>
#include <hal_io.h>
#include <hal_sleep.h>

#include <hal_ext_irq.h>

#include <hal_flash.h>

#include <hal_usart_async.h>

#include <hal_usart_os.h>
#include <hal_usart_async.h>

#include <hal_i2c_s_async.h>
#include <hal_can_async.h>

#define SERIAL_FLEX2_BUFFER_SIZE 16

#define SERCOM4_I2CS_BUFFER_SIZE 16

extern struct flash_descriptor       FLASH_0;
extern struct usart_async_descriptor SERIAL_IR;

extern struct usart_os_descriptor    SERIAL_FLEX2;
extern uint8_t                       SERIAL_FLEX2_buffer[];
extern struct usart_async_descriptor SERIAL_LORA;

extern struct i2c_s_async_descriptor I2C_FLEX4;
extern struct can_async_descriptor   CAN_0;

void FLASH_0_init(void);
void FLASH_0_CLOCK_init(void);

void SERIAL_IR_PORT_init(void);
void SERIAL_IR_CLOCK_init(void);
void SERIAL_IR_init(void);

void SERIAL_FLEX2_PORT_init(void);
void SERIAL_FLEX2_CLOCK_init(void);
void SERIAL_FLEX2_init(void);

void SERIAL_LORA_PORT_init(void);
void SERIAL_LORA_CLOCK_init(void);
void SERIAL_LORA_init(void);

void I2C_FLEX4_PORT_init(void);
void I2C_FLEX4_CLOCK_init(void);
void I2C_FLEX4_init(void);

/**
 * \brief Perform system initialization, initialize pins and clocks for
 * peripherals
 */
void system_init(void);

#ifdef __cplusplus
}
#endif
#endif // DRIVER_INIT_INCLUDED
