/*
 * Code generated from Atmel Start.
 *
 * This file will be overwritten when reconfiguring your Atmel Start project.
 * Please copy examples or other code you want to keep to a separate file
 * to avoid losing it when reconfiguring.
 */

#include "driver_examples.h"
#include "driver_init.h"
#include "utils.h"

static void button_on_PA20_pressed(void)
{
}

static void button_on_PA10_pressed(void)
{
}

static void button_on_PA14_pressed(void)
{
}

/**
 * Example of using EXTERNAL_IRQ_0
 */
void EXTERNAL_IRQ_0_example(void)
{

	ext_irq_register(PIN_PA20, button_on_PA20_pressed);
	ext_irq_register(PIN_PA10, button_on_PA10_pressed);
	ext_irq_register(PIN_PA14, button_on_PA14_pressed);
}

static uint8_t src_data[512];
static uint8_t chk_data[512];
/**
 * Example of using FLASH_0 to read and write Flash main array.
 */
void FLASH_0_example(void)
{
	uint32_t page_size;
	uint16_t i;

	/* Init source data */
	page_size = flash_get_page_size(&FLASH_0);

	for (i = 0; i < page_size; i++) {
		src_data[i] = i;
	}

	/* Write data to flash */
	flash_write(&FLASH_0, 0x3200, src_data, page_size);

	/* Read data from flash */
	flash_read(&FLASH_0, 0x3200, chk_data, page_size);
}

/**
 * Example of using SERIAL_IR to write "Hello World" using the IO abstraction.
 *
 * Since the driver is asynchronous we need to use statically allocated memory for string
 * because driver initiates transfer and then returns before the transmission is completed.
 *
 * Once transfer has been completed the tx_cb function will be called.
 */

static uint8_t example_SERIAL_IR[12] = "Hello World!";

static void tx_cb_SERIAL_IR(const struct usart_async_descriptor *const io_descr)
{
	/* Transfer completed */
}

void SERIAL_IR_example(void)
{
	struct io_descriptor *io;

	usart_async_register_callback(&SERIAL_IR, USART_ASYNC_TXC_CB, tx_cb_SERIAL_IR);
	/*usart_async_register_callback(&SERIAL_IR, USART_ASYNC_RXC_CB, rx_cb);
	usart_async_register_callback(&SERIAL_IR, USART_ASYNC_ERROR_CB, err_cb);*/
	usart_async_get_io_descriptor(&SERIAL_IR, &io);
	usart_async_enable(&SERIAL_IR);

	io_write(io, example_SERIAL_IR, 12);
}

/**
 * Example task of using SERIAL_FLEX2 to echo using the IO abstraction.
 */
void SERIAL_FLEX2_example_task(void *p)
{
	struct io_descriptor *io;
	uint16_t              data;

	(void)p;

	usart_os_get_io(&SERIAL_FLEX2, &io);

	for (;;) {
		if (io->read(io, (uint8_t *)&data, 1) == 1) {
			io->write(io, (uint8_t *)&data, 1);
		}
	}
}

/**
 * Example of using SERIAL_LORA to write "Hello World" using the IO abstraction.
 *
 * Since the driver is asynchronous we need to use statically allocated memory for string
 * because driver initiates transfer and then returns before the transmission is completed.
 *
 * Once transfer has been completed the tx_cb function will be called.
 */

static uint8_t example_SERIAL_LORA[12] = "Hello World!";

static void tx_cb_SERIAL_LORA(const struct usart_async_descriptor *const io_descr)
{
	/* Transfer completed */
}

void SERIAL_LORA_example(void)
{
	struct io_descriptor *io;

	usart_async_register_callback(&SERIAL_LORA, USART_ASYNC_TXC_CB, tx_cb_SERIAL_LORA);
	/*usart_async_register_callback(&SERIAL_LORA, USART_ASYNC_RXC_CB, rx_cb);
	usart_async_register_callback(&SERIAL_LORA, USART_ASYNC_ERROR_CB, err_cb);*/
	usart_async_get_io_descriptor(&SERIAL_LORA, &io);
	usart_async_enable(&SERIAL_LORA);

	io_write(io, example_SERIAL_LORA, 12);
}

static struct io_descriptor *io;

static void I2C_FLEX4_rx_complete(const struct i2c_s_async_descriptor *const descr)
{
	uint8_t c;

	io_read(io, &c, 1);
}

void I2C_FLEX4_example(void)
{
	i2c_s_async_get_io_descriptor(&I2C_FLEX4, &io);
	i2c_s_async_register_callback(&I2C_FLEX4, I2C_S_RX_COMPLETE, I2C_FLEX4_rx_complete);
	i2c_s_async_enable(&I2C_FLEX4);
}

void CAN_0_tx_callback(struct can_async_descriptor *const descr)
{
	(void)descr;
}
void CAN_0_rx_callback(struct can_async_descriptor *const descr)
{
	struct can_message msg;
	uint8_t            data[64];
	msg.data = data;
	can_async_read(descr, &msg);
	return;
}

/**
 * Example of using CAN_0 to Encrypt/Decrypt datas.
 */
void CAN_0_example(void)
{
	struct can_message msg;
	struct can_filter  filter;
	uint8_t            send_data[4];
	send_data[0] = 0x00;
	send_data[1] = 0x01;
	send_data[2] = 0x02;
	send_data[3] = 0x03;

	msg.id   = 0x45A;
	msg.type = CAN_TYPE_DATA;
	msg.data = send_data;
	msg.len  = 4;
	msg.fmt  = CAN_FMT_STDID;
	can_async_register_callback(&CAN_0, CAN_ASYNC_TX_CB, (FUNC_PTR)CAN_0_tx_callback);
	can_async_enable(&CAN_0);

	/**
	 * CAN_0_tx_callback callback should be invoked after call
	 * can_async_write, and remote device should recieve message with ID=0x45A
	 */
	can_async_write(&CAN_0, &msg);

	msg.id  = 0x100000A5;
	msg.fmt = CAN_FMT_EXTID;
	/**
	 * remote device should recieve message with ID=0x100000A5
	 */
	can_async_write(&CAN_0, &msg);

	/**
	 * CAN_0_rx_callback callback should be invoked after call
	 * can_async_set_filter and remote device send CAN Message with the same
	 * content as the filter.
	 */
	can_async_register_callback(&CAN_0, CAN_ASYNC_RX_CB, (FUNC_PTR)CAN_0_rx_callback);
	filter.id   = 0x469;
	filter.mask = 0;
	can_async_set_filter(&CAN_0, 0, CAN_FMT_STDID, &filter);

	filter.id   = 0x10000096;
	filter.mask = 0;
	can_async_set_filter(&CAN_0, 1, CAN_FMT_EXTID, &filter);
}
