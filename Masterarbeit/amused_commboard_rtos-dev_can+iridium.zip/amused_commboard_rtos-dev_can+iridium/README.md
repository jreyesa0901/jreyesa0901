# AMuSeD_commboard_rtos

This is only the Atmel Studio 7 project for main configuration of the RTOS and other peripherals of the communication board. 
It is important to add the libs repository which is independent from this project such that it can be ported to other platfo